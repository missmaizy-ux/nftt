export class Prices {
  BTC: string;
  ETH: string;
  CELO: string;
  USD: string;
  BRL: string;
  JPY?: string;
  EUR: string;
  HTR: string;
  MDA: string;
  BNB: string;
  ADA: string;
  XLM: string;
  XRP: string;
}
