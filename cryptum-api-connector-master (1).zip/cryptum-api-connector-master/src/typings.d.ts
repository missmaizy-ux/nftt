declare module '*.json' {
  export const title: string;
  export const description: string;
}
